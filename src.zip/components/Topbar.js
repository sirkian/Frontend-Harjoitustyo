import React from "react";

function Topbar() {
  return (
    <div className="topContainer">
      <h2>Taas yksi reseptisivu</h2>
    </div>
  );
}

export default Topbar;
